<?php
require_once 'team.php'; 
$teamMembers = getAllTeamMembers(); 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Team Members List</title>
</head>
<body>
    <h1>Team Members</h1>
    <a href="create.php">Add New Team Member</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Position</th>
            <th>Email</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($teamMembers as $member): ?>
            <tr>
                <td><?php echo $member['id']; ?></td>
                <td><?php echo $member['name']; ?></td>
                <td><?php echo $member['position']; ?></td>
                <td><?php echo $member['email']; ?></td>
                <td>
                    <a href="detail.php?id=<?php echo $member['id']; ?>">View</a>
                    <a href="edit.php?id=<?php echo $member['id']; ?>">Edit</a>
                    <a href="delete.php?id=<?php echo $member['id']; ?>">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
