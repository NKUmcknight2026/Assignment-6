<?php
require_once 'team.php';  

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'name' => $_POST['name'],
        'position' => $_POST['position'],
        'email' => $_POST['email'],
        'phone' => $_POST['phone']
    ];
    createTeamMember($data);  
    header("Location: index.php");  
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add New Team Member</title>
</head>
<body>
    <h1>Add New Team Member</h1>
    <form method="post">
        <label>Name:</label>
        <input type="text" name="name" required><br>
        <label>Position:</label>
        <input type="text" name="position" required><br>
        <label>Email:</label>
        <input type="email" name="email" required><br>
        <label>Phone:</label>
        <input type="text" name="phone" required><br>
        <button type="submit">Add</button>
    </form>
</body>
</html>
