<?php

function getAllAwards() {
    global $db;
    $query = "SELECT * FROM awards";
    $result = $db->query($query);
    return $result->fetchAll(PDO::FETCH_ASSOC);
}

function getAwardById($id) {
    global $db;
    $query = "SELECT * FROM awards WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function createAward($data) {
    global $db;
    $query = "INSERT INTO awards (title, description, year) VALUES (:title, :description, :year)";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':title', $data['title'], PDO::PARAM_STR);
    $stmt->bindParam(':description', $data['description'], PDO::PARAM_STR);
    $stmt->bindParam(':year', $data['year'], PDO::PARAM_INT);
    $stmt->execute();
}

function updateAward($id, $data) {
    global $db;
    $query = "UPDATE awards SET title = :title, description = :description, year = :year WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':title', $data['title'], PDO::PARAM_STR);
    $stmt->bindParam(':description', $data['description'], PDO::PARAM_STR);
    $stmt->bindParam(':year', $data['year'], PDO::PARAM_INT);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}

function deleteAward($id) {
    global $db;
    $query = "DELETE FROM awards WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}
?>
