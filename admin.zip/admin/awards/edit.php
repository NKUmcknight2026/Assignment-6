<?php
require_once 'awards.php';  
$id = $_GET['id'];
$award = getAwardById($id);  

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'title' => $_POST['title'],
        'description' => $_POST['description'],
        'year' => $_POST['year']
    ];
    updateAward($id, $data);  
    header("Location: detail.php?id=" . $id);  
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Award</title>
</head>
<body>
    <h1>Edit Award</h1>
    <form method="post">
        <label>Title:</label>
        <input type="text" name="title" value="<?php echo $award['title']; ?>" required><br>
        <label>Description:</label>
        <textarea name="description" required><?php echo $award['description']; ?></textarea><br>
        <label>Year:</label>
        <input type="number" name="year" value="<?php echo $award['year']; ?>" required><br>
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>
