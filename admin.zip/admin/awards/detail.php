<?php
require_once 'awards.php';  
$id = $_GET['id'];
$award = getAwardById($id); 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Award Detail</title>
</head>
<body>
    <h1><?php echo $award['title']; ?></h1>
    <p><strong>Description:</strong> <?php echo $award['description']; ?></p>
    <p><strong>Year:</strong> <?php echo $award['year']; ?></p>
    <a href="edit.php?id=<?php echo $award['id']; ?>">Edit</a>
    <a href="delete.php?id=<?php echo $award['id']; ?>">Delete</a>
    <br>
    <a href="index.php">Back to Awards List</a>
</body>
</html>
