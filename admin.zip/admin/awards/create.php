<?php
require_once 'awards.php';  

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'title' => $_POST['title'],
        'description' => $_POST['description'],
        'year' => $_POST['year']
    ];
    createAward($data); 
    header("Location: index.php");  
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create New Award</title>
</head>
<body>
    <h1>Create Award</h1>
    <form method="post">
        <label>Title:</label>
        <input type="text" name="title" required><br>
        <label>Description:</label>
        <textarea name="description" required></textarea><br>
        <label>Year:</label>
        <input type="number" name="year" required><br>
        <button type="submit">Create</button>
    </form>
</body>
</html>
