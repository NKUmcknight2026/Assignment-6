<?php
require_once 'awards.php';  
$awards = getAllAwards();  
?>

<!DOCTYPE html>
<html>
<head>
    <title>Awards List</title>
</head>
<body>
    <h1>Awards</h1>
    <a href="create.php">Create New Award</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Year</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($awards as $award): ?>
            <tr>
                <td><?php echo $award['id']; ?></td>
                <td><?php echo $award['title']; ?></td>
                <td><?php echo $award['description']; ?></td>
                <td><?php echo $award['year']; ?></td>
                <td>
                    <a href="detail.php?id=<?php echo $award['id']; ?>">View</a>
                    <a href="edit.php?id=<?php echo $award['id']; ?>">Edit</a>
                    <a href="delete.php?id=<?php echo $award['id']; ?>">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
