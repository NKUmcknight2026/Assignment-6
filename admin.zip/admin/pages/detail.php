<?php
require_once 'pages.php';  
$id = $_GET['id'];
$page = getPageById($id);  
?>

<!DOCTYPE html>
<html>
<head>
    <title>Page Detail</title>
</head>
<body>
    <h1><?php echo $page['title']; ?></h1>
    <p><strong>Content:</strong></p>
    <p><?php echo $page['content']; ?></p>
    <a href="edit.php?id=<?php echo $page['id']; ?>">Edit</a>
    <a href="delete.php?id=<?php echo $page['id']; ?>">Delete</a>
    <br>
    <a href="index.php">Back to Pages List</a>
</body>
</html>
