<?php
require_once 'pages.php';  
$id = $_GET['id'];
$page = getPageById($id);  

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'title' => $_POST['title'],
        'content' => $_POST['content']
    ];
    updatePage($id, $data);  
    header("Location: detail.php?id=" . $id);
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Page</title>
</head>
<body>
    <h1>Edit Page</h1>
    <form method="post">
        <label>Title:</label>
        <input type="text" name="title" value="<?php echo $page['title']; ?>" required><br>
        <label>Content:</label>
        <textarea name="content" required><?php echo $page['content']; ?></textarea><br>
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>
