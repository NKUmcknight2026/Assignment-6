<?php

function getAllPages() {
    global $db;
    $query = "SELECT * FROM pages";
    $result = $db->query($query);
    return $result->fetchAll(PDO::FETCH_ASSOC);
}

function getPageById($id) {
    global $db;
    $query = "SELECT * FROM pages WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function createPage($data) {
    global $db;
    $query = "INSERT INTO pages (title, content) VALUES (:title, :content)";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':title', $data['title'], PDO::PARAM_STR);
    $stmt->bindParam(':content', $data['content'], PDO::PARAM_STR);
    $stmt->execute();
}

function updatePage($id, $data) {
    global $db;
    $query = "UPDATE pages SET title = :title, content = :content WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':title', $data['title'], PDO::PARAM_STR);
    $stmt->bindParam(':content', $data['content'], PDO::PARAM_STR);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}

function deletePage($id) {
    global $db;
    $query = "DELETE FROM pages WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}
?>
