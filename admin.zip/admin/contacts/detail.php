<?php
require_once 'contacts.php';  
$id = $_GET['id'];
$contact = getContactById($id);  
?>

<!DOCTYPE html>
<html>
<head>
    <title>Contact Request Details</title>
</head>
<body>
    <h1>Contact Request from <?php echo $contact['name']; ?></h1>
    <p><strong>Email:</strong> <?php echo $contact['email']; ?></p>
    <p><strong>Message:</strong></p>
    <p><?php echo $contact['message']; ?></p>
    <a href="index.php">Back to Contact Requests</a>
</body>
</html>
