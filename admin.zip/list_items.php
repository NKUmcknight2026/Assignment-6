<?php
session_start();
if (!isset($_SESSION['logged_in'])) {
    header('Location: login.php');
    exit;
}

function loadItems() {
    $items = [];
    $file = fopen('pages.txt', 'r');
    while (($line = fgets($file)) !== false) {
        list($name, $content) = explode('|', trim($line));
        $items[$name] = $content;
    }
    fclose($file);
    return $items;
}

$items = loadItems();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Items</title>
</head>
<body>
    <h1>Manage Items</h1>
    <a href="edit_item.php">Create New Item</a><br><br>
    <table border="1">
        <tr>
            <th>Name</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($items as $name => $content): ?>
        <tr>
            <td><?php echo htmlspecialchars($name); ?></td>
            <td>
                <a href="edit_item.php?name=<?php echo urlencode($name); ?>">Edit</a>
                <a href="delete_item.php?name=<?php echo urlencode($name); ?>">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
