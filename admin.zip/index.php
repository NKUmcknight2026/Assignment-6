<?php
session_start();

// Handle signup logic (existing code)
$signupError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signup'])) {
    $username = $_POST['signup_username'];
    $password = $_POST['signup_password'];
    
    // Check if the user already exists
    $userExists = false;
    if (file_exists('users.txt')) {
        $file = fopen('users.txt', 'r');
        while (($line = fgets($file)) !== false) {
            list($existingUser) = explode('|', trim($line));
            if ($existingUser === $username) {
                $userExists = true;
                break;
            }
        }
        fclose($file);
    }
    
    if ($userExists) {
        $signupError = "Username already exists. Please choose another.";
    } else {
        // Save user to users.txt
        $file = fopen('users.txt', 'a');
        fwrite($file, "$username|$password\n");
        fclose($file);
        header('Location: index.php'); // Redirect to the success page
        exit;
    }
}

// Handle login logic
$loginError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = $_POST['login_username'];
    $password = $_POST['login_password'];

    // Check credentials
    $userFound = false;
    if (file_exists('users.txt')) {
        $file = fopen('users.txt', 'r');
        while (($line = fgets($file)) !== false) {
            list($existingUser, $existingPassword) = explode('|', trim($line));
            if ($existingUser === $username && $existingPassword === $password) {
                $_SESSION['logged_in'] = true;
                $_SESSION['username'] = $username; // Store the username
                $userFound = true;
                break;
            }
        }
        fclose($file);
    }

    if (!$userFound) {
        $loginError = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index Page</title>
</head>
<body>
    <h1>Welcome to Our Site</h1>

    <!-- Signup Form -->
    <h2>Sign Up</h2>
    <?php if ($signupError): ?>
        <p style="color: red;"><?php echo $signupError; ?></p>
    <?php endif; ?>
    <form method="POST">
        <input type="text" name="signup_username" placeholder="Username" required>
        <input type="password" name="signup_password" placeholder="Password" required>
        <button type="submit" name="signup">Sign Up</button>
    </form>

    <!-- Login Form -->
    <h2>Login</h2>
    <?php if ($loginError): ?>
        <p style="color: red;"><?php echo $loginError; ?></p>
    <?php endif; ?>
    <form method="POST">
        <input type="text" name="login_username" placeholder="Username" required>
        <input type="password" name="login_password" placeholder="Password" required>
        <button type="submit" name="login">Login</button>
    </form>

    <!-- Display logged-in user -->
    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
        <h3>Hello, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h3>
        <a href="logout.php">Logout</a> <!-- Add a logout link -->
    <?php endif; ?>
</body>
</html>
