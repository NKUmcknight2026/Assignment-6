<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

$itemID = $_GET['id'] ?? null;
$itemName = '';
$successMessage = '';

if ($itemID) {
    // Load the existing item from items.txt
    $items = [];
    if (file_exists('items.txt')) {
        $file = fopen('items.txt', 'r');
        while (($line = fgets($file)) !== false) {
            list($id, $name) = explode('|', trim($line));
            if ($id === $itemID) {
                $itemName = $name; // Get the item name
            }
            $items[] = ['id' => $id, 'name' => $name];
        }
        fclose($file);
    }

    // Handle updating the item
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $newName = $_POST['item_name'];

        // Update the item in items.txt
        $file = fopen('items.txt', 'w');
        foreach ($items as $item) {
            if ($item['id'] === $itemID) {
                fwrite($file, "$itemID|$newName\n");
            } else {
                fwrite($file, "{$item['id']}|{$item['name']}\n");
            }
        }
        fclose($file);

        $successMessage = 'Item updated successfully!';
        header("Location: admin_dashboard.php"); // Redirect after update
        exit;
    }
} else {
    header('Location: admin_dashboard.php'); // Redirect if no ID
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Item</title>
</head>
<body>
    <h1>Edit Item</h1>
    <?php if ($successMessage): ?>
        <p style="color: green;"><?php echo $successMessage; ?></p>
    <?php endif; ?>
    <form method="POST">
        <label for="item_name">Item Name:</label>
        <input type="text" name="item_name" value="<?php echo htmlspecialchars($itemName); ?>" required>
        <br>
        <button type="submit">Update</button>
    </form>
    <a href="admin_dashboard.php">Back to Dashboard</a>
</body>
</html>
